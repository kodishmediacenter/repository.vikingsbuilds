import base64
base = 'Wl1RmtmSrdzL3Fmcv02bj5ibpJWZ0NXYw9yL6MHc0RHa'
tam = len(base)
basedem = base[::-1]
print(basedem)

#MainBase ='https://pastebin.com/raw/7kJkfGYV'
