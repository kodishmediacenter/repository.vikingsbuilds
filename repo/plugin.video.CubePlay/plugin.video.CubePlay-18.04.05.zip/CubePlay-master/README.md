# Cube Play link alternativo:
http://cubeplay.000webhostapp.com/plugin.video.CubePlay.zip

Addon modificado do PlaylistLoader 1.2.0 por Avigdor https://github.com/avigdork/xbmc-avigdork.

Nao somos responsaveis por colocar o conteudo online, apenas indexamos.

Link encurtado para download: http://bit.ly/CUBEPLAY

Para sugestoes e report de bugs nossa pagina no FB: http://fb.com/CubePlayKodi
